package model;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import nnet.LinearTanh;
import nnet.NNInterface;

public class MLP implements NNInterface{
	public List<LinearTanh> LinearTanhList;
	public int InputLength; 
	public int OutputLength;
	public int Layers;
	
	public double[] input;
	public double[] output;
	
	public double[] inputG;
	public double[] outputG;
	
	int linkId;
	
	public MLP() {
	}
	
	public MLP(int xInputLength,int xOutputLength,int xLayers) throws Exception {
		InputLength = xInputLength;
		OutputLength = xOutputLength;
		Layers = xLayers;
		LinearTanhList = new ArrayList<LinearTanh>();
		if(Layers>=1){
			if(Layers==1)
				LinearTanhList.add(new LinearTanh(InputLength, OutputLength));
			else{
				for(int Layer=0; Layer<Layers;Layer++){
					if(0==Layer)
						LinearTanhList.add(new LinearTanh(InputLength, OutputLength*(int)Math.pow(2, Layers-1)));
					else
						LinearTanhList.add(new LinearTanh(OutputLength*(int)Math.pow(2,Layers-Layer), OutputLength*(int)Math.pow(2,Layers-Layer-1)));
				}
				for(int Layer=0; Layer<(Layers-1); Layer++){
					LinearTanhList.get(Layer).link(LinearTanhList.get(Layer+1));
				}
			}
			input = LinearTanhList.get(0).linear.input;
			inputG = LinearTanhList.get(0).linear.inputG;
		}
		else{
			input = new double[InputLength];
			inputG = new double[InputLength];
		}
		output = new double[OutputLength];
		outputG = new double[OutputLength];
		linkId = 0;
	}
	
	@Override
	public void randomize(Random r, double min, double max) {
		for(int Layer=0; Layer<Layers; Layer++){
			LinearTanhList.get(Layer).randomize(r, min, max);
		}
	}
	
	public void XavierInitialization(Random r){
		for(int Layer=0; Layer<Layers; Layer++){
			LinearTanhList.get(Layer).XavierInitialization(r);
		}
	}

	@Override
	public void forward() {
		if(Layers>=1){
			for(int Layer=0; Layer<Layers; Layer++){
				LinearTanhList.get(Layer).forward();
			}
		}else{
			for(int i=0; i<OutputLength; i++){
				output[i] = input[i];
			}
		}
	}

	@Override
	public void backward() {
		if(Layers>=1){
			for(int Layer=0; Layer<Layers; Layer++){
				LinearTanhList.get(Layers-1-Layer).backward();
			}
		}else{
			for(int i=0; i<InputLength; i++){
				inputG[i] = outputG[i];
			}
		}
	}

	@Override
	public void update(double learningRate) {
		if(Layers>=1)
		for(int Layer=0; Layer<Layers; Layer++){
			LinearTanhList.get(Layer).update(learningRate);
		}
	}
	
	public void update(double learningRate, double lamda) {
		if(Layers>=1)
		for(int Layer=0; Layer<Layers; Layer++){
			LinearTanhList.get(Layer).update(learningRate, lamda);
		}
	}

	@Override
	public void updateAdaGrad(double learningRate, int batchsize) {
	}

	@Override
	public void clearGrad() {
		if(Layers>=1){
			for(int Layer=0; Layer<Layers; Layer++)
				LinearTanhList.get(Layer).clearGrad();
		}else{
			for(int i = 0; i < inputG.length; i++)
				inputG[i] = 0;
		}
		
		for(int i = 0; i < outputG.length; i++)
		{
			outputG[i] = 0;
		}
	}

	@Override
	public void link(NNInterface nextLayer, int id) throws Exception {
		Object nextInputG = nextLayer.getInputG(id);
		Object nextInput = nextLayer.getInput(id);
		
		double[] nextI = (double[])nextInput;
		double[] nextIG = (double[])nextInputG; 
		
		if(Layers>=1){
			if(nextI.length != LinearTanhList.get(Layers-1).OutputLength 
					|| nextIG.length != LinearTanhList.get(Layers-1).OutputLength)
			{
				throw new Exception("The Lengths of linked layers do not match.");
			}
			LinearTanhList.get(Layers-1).tanh.output = nextI;
			LinearTanhList.get(Layers-1).tanh.outputG = nextIG;
		}else{
			if(nextI.length != output.length || nextIG.length != outputG.length)
			{
				throw new Exception("The Lengths of linked layers do not match.");
			}
			output = nextI;
			outputG = nextIG;
		}
	}

	@Override
	public void link(NNInterface nextLayer) throws Exception {
		link(nextLayer, linkId);
	}

	@Override
	public Object getInput(int id) {
			return input;
	}

	@Override
	public Object getOutput(int id) {
		if(Layers>=1)
			return LinearTanhList.get(Layers-1).tanh.output;
		else
			return output;
	}

	@Override
	public Object getInputG(int id) {
		return inputG;
	}

	@Override
	public Object getOutputG(int id) {
		if(Layers>=1)
			return LinearTanhList.get(Layers-1).tanh.outputG;
		else
			return outputG;
	}

	@Override
	public Object cloneWithTiedParams() {
		return null;
	}
	
	public void regularizationMLP(double lambda) {
		for(LinearTanh linearTanh: LinearTanhList){
			linearTanh.regularizationLinear(lambda);
		}
	}

}
