package model;

import java.util.Random;

import nnet.ElementWiseProdLayer;
import nnet.NNInterface;
import nnet.OutputWeightLayer;

public class NeuralCF implements NNInterface{

	public int length;
	public int linkId;
	public int[] inputLengths;
	public double[][] input;
	public double[][] inputG;
	public double[] output;
	public double[] outputG;
	public int outputLength;
	public int mlpL;
	
	public ElementWiseProdLayer elemWiseProduct;
	public MLP mlpUIR;
	public OutputWeightLayer outputWeight;
	
	public NeuralCF(int[] xInputLengths, int xOutputLength) throws Exception
	{
		this(0, xInputLengths, xOutputLength);
	}
	
	public NeuralCF(int xLinkId, int[] xInputLengths, int xOutputLength, int XmlpL) throws Exception
	{
		this.mlpL = XmlpL;
		linkId = xLinkId;
		inputLengths = xInputLengths;
		outputLength = xOutputLength;
    	elemWiseProduct = new ElementWiseProdLayer(inputLengths, inputLengths[0]);
    	mlpUIR = new MLP(elemWiseProduct.outputLength, elemWiseProduct.outputLength/2,1);
    	outputWeight = new OutputWeightLayer(elemWiseProduct.outputLength/2,outputLength);
    	
    	elemWiseProduct.link(mlpUIR);
    	mlpUIR.link(outputWeight);
    	input = elemWiseProduct.input;
    	inputG = elemWiseProduct.inputG;
    	output = outputWeight.output;
    	outputG = outputWeight.outputG;
	}
	
	public NeuralCF(int xLinkId, int[] xInputLengths, int xOutputLength) throws Exception
	{
		this(xLinkId, xInputLengths, xOutputLength, 1);
	}
	
	public void XavierInitialization(Random r){
		outputWeight.XavierInitialization(r);
	}
	
	@Override
	public void randomize(Random r, double min, double max) {
		outputWeight.randomize(r, min, max);
	}

	@Override
	public void forward() {
		elemWiseProduct.forward();
		mlpUIR.forward();
		outputWeight.forward();	
	}

	@Override
	public void backward() {
		outputWeight.backward();
		mlpUIR.backward();
		elemWiseProduct.backward();
	}

	@Override
	public void update(double learningRate) {
		mlpUIR.update(learningRate);
		outputWeight.update(learningRate);
	}

	@Override
	public void updateAdaGrad(double learningRate, int batchsize) {
	}

	@Override
	public void clearGrad() {
		elemWiseProduct.clearGrad();
		mlpUIR.clearGrad();
		outputWeight.clearGrad();
	}

	@Override
	public void link(NNInterface nextLayer, int id) throws Exception {
		Object nextInputG = nextLayer.getInputG(id);
		Object nextInput = nextLayer.getInput(id);
		
		double[] nextI = (double[])nextInput;
		double[] nextIG = (double[])nextInputG; 
		
		if(nextI.length != output.length || nextIG.length != outputG.length)
		{
			throw new Exception("The Lengths of linked layers do not match.");
		}
		output = nextI;
		outputG = nextIG;
	}

	@Override
	public void link(NNInterface nextLayer) throws Exception {
		link(nextLayer, linkId);
	}

	@Override
	public Object getInput(int id) {
		return input[id];
	}

	@Override
	public Object getOutput(int id) {
		return output[id];
	}

	@Override
	public Object getInputG(int id) {
		return inputG[id];
	}

	@Override
	public Object getOutputG(int id) {
		return outputG[id];
	}

	@Override
	public Object cloneWithTiedParams() {
		return null;
	}

	public void regularizationNeuralCF(double lambda) {
		mlpUIR.regularizationMLP(lambda);
		outputWeight.regularizationLinear(lambda);
	}
}
