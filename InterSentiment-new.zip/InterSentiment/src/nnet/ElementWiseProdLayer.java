package nnet;

import java.util.Random;

import nnet.NNInterface;

public class ElementWiseProdLayer implements NNInterface{

	public int length;
	public int linkId;
	public int[] inputLengths;
	public double[][] input;
	public double[][] inputG;
	public double[] output;
	public double[] outputG;
	public int outputLength;

	
	public ElementWiseProdLayer(int[] xInputLengths, int xOutputLength) throws Exception
	{
		this(0,xInputLengths, xOutputLength);
	}
	
	public ElementWiseProdLayer(int xLinkId, int[] xInputLengths, int xOutputLength) throws Exception
	{
		linkId = xLinkId;
		inputLengths = xInputLengths;
		outputLength = xOutputLength;
		
		input = new double[inputLengths.length][];
    	inputG = new double[inputLengths.length][];
		
		for(int i = 0; i < inputLengths.length; i++)
    	{
    		input[i] = new double[inputLengths[i]];
    		inputG[i] = new double[inputLengths[i]];
    	}

		output = new double[outputLength];
    	outputG = new double[outputLength];
    	linkId = 0;
	}
	
	@Override
	public void randomize(Random r, double min, double max) {
		
	}

	@Override
	public void forward() {
		for(int i=0; i <outputLength; i++){
			output[i] = input[0][i] * input[1][i];
		}
	}

	@Override
	public void backward() {
		for(int i=0; i< outputLength; i++)
			inputG[0][i] += outputG[i]*input[1][i];
		for(int i=0; i< outputLength; i++)
			inputG[1][i] += outputG[i]*input[0][i];
	}

	@Override
	public void update(double learningRate) {
		// TODO Auto-generated method stub
	}

	@Override
	public void updateAdaGrad(double learningRate, int batchsize) {
		// TODO Auto-generated method stub
	}

	@Override
	public void clearGrad() {
		for(int i = 0; i < outputG.length; i++)
		{
			outputG[i] = 0;
		}
		
		for(int i = 0; i < inputG.length; i++)
		{
			for(int j = 0; j < inputG[i].length; j++)
			{
				inputG[i][j] = 0;
			}
		}
	}

	@Override
	public void link(NNInterface nextLayer, int id) throws Exception {
		Object nextInputG = nextLayer.getInputG(id);
		Object nextInput = nextLayer.getInput(id);
		
		double[] nextI = (double[])nextInput;
		double[] nextIG = (double[])nextInputG; 
		
		if(nextI.length != output.length || nextIG.length != outputG.length)
		{
			throw new Exception("The Lengths of linked layers do not match.");
		}
		output = nextI;
		outputG = nextIG;
	}

	@Override
	public void link(NNInterface nextLayer) throws Exception {
		link(nextLayer, linkId);
	}

	@Override
	public Object getInput(int id) {
		return input[id];
	}

	@Override
	public Object getOutput(int id) {
		return output;
	}

	@Override
	public Object getInputG(int id) {
		return inputG[id];
	}

	@Override
	public Object getOutputG(int id) {
		return outputG;
	}

	@Override
	public Object cloneWithTiedParams() {
		return null;
	}

}
